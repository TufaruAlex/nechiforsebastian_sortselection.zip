/*      Programul numarul 4:
    4.Parcurgerea NS de la coada spre inceput   */
#include<iostream>
#include<limits.h>
using namespace std;
int V[100];
int n;
int main(){
    cout<<"n = ";cin>>n;
    for(int i=1;i<=n;i++){
        cout<<"V["<<i<<"] = ";
        cin>>V[i];}
    for(int i=n;i>0;i--){
        int minim=INT_MIN;
        int top=0;
        for(int j=i;j>0;j--){
            if(V[j]>minim){
                minim=V[j];
                top=j;}}
        swap(V[i],V[top]);}
    cout<<endl<<"Numerele au fost sortate ^.^ "<<endl;
    for(int i=1;i<=n;i++){
    cout<<V[i]<<" ";}
    return 1;}
